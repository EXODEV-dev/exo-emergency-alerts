Config = {}

Config.ServerName = "EXO Development"

Config.Departments = {
    police = {
        label = "POLICE",
        colour = "blue"
    },

    ambulance = {
        label = "AMBULANCE",
        colour = "red"
    },

    fire = {
        label = "FIRE & RESCUE",
        colour = "orange"
    }
}

Config.Calls = {
    {
        code = "GRADE 1",
        label = "Robbery In Progress",
        priority = "HIGH"
    },

    {
        code = "GRADE 3",
        label = "Vehicle Stop",
        priority = "LOW"
    },

    {
        code = "GRADE 1",
        label = "Road Traffic Collision",
        priority = "HIGH"
    },

    {
        code = "GRADE 1",
        label = "Officer In Danger",
        priority = "CRITICAL"
    }
}