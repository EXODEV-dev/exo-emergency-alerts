```javascript
const dispatch = document.getElementById("dispatch");
const closeButton = document.getElementById("close-button");

const callsPage = document.getElementById("calls-page");
const createPage = document.getElementById("create-page");

const callsList = document.getElementById("calls-list");
const callCount = document.getElementById("call-count");

const createCallButton = document.getElementById("create-call");

const departmentInput = document.getElementById("department");
const priorityInput = document.getElementById("priority");
const messageInput = document.getElementById("call-message");

const navButtons = document.querySelectorAll(".nav-button");

let calls = {};


// ==========================================
// FiveM messages
// ==========================================

window.addEventListener("message", function(event) {

    const data = event.data;

    if (data.action === "open") {
        dispatch.style.display = "block";
    }

    if (data.action === "close") {
        dispatch.style.display = "none";
    }

    if (data.action === "newCall") {

        if (data.call) {
            calls[data.call.id] = data.call;
            renderCalls();
        }
    }

    if (data.action === "callAccepted") {

        const call = calls[data.callId];

        if (call) {
            call.acceptedBy = data.playerName;
            renderCalls();
        }
    }

    if (data.action === "callClosed") {

        delete calls[data.callId];

        renderCalls();
    }

});


// ==========================================
// Navigation
// ==========================================

navButtons.forEach(function(button) {

    button.addEventListener("click", function() {

        navButtons.forEach(function(btn) {
            btn.classList.remove("active");
        });

        button.classList.add("active");

        const page = button.dataset.page;

        if (page === "calls") {

            callsPage.classList.remove("hidden");
            createPage.classList.add("hidden");

        }

        if (page === "create") {

            callsPage.classList.add("hidden");
            createPage.classList.remove("hidden");

        }

    });

});


// ==========================================
// Close menu
// ==========================================

closeButton.addEventListener("click", function() {

    fetch(`https://${GetParentResourceName()}/close`, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({})
    });

});


// ==========================================
// Create dispatch call
// ==========================================

createCallButton.addEventListener("click", function() {

    const message =
        messageInput.value.trim();

    const department =
        departmentInput.value;

    const priority =
        priorityInput.value;


    if (message === "") {

        messageInput.focus();

        return;
    }


    fetch(`https://${GetParentResourceName()}/createCall`, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            message: message,

            department: department,

            priority: priority

        })

    });


    messageInput.value = "";


    // Return to active calls

    callsPage.classList.remove("hidden");
    createPage.classList.add("hidden");

    navButtons.forEach(function(button) {

        button.classList.remove("active");

    });

    navButtons[0].classList.add("active");

});


// ==========================================
// Render calls
// ==========================================

function renderCalls() {

    const callArray =
        Object.values(calls);


    callCount.textContent =
        `${callArray.length} CALL${callArray.length === 1 ? "" : "S"}`;


    if (callArray.length === 0) {

        callsList.innerHTML = `

            <div class="no-calls">

                <div class="no-calls-icon">
                    ✓
                </div>

                <h3>
                    No Active Calls
                </h3>

                <p>
                    There are currently no active emergency calls.
                </p>

            </div>

        `;

        return;
    }


    callsList.innerHTML = "";


    callArray.reverse().forEach(function(call) {

        const callElement =
            document.createElement("div");

        callElement.classList.add("call");


        let priorityClass =
            "priority-low";

        if (call.priority === "HIGH") {
            priorityClass =
                "priority-high";
        }

        if (call.priority === "CRITICAL") {
            priorityClass =
                "priority-critical";
        }


        let acceptedText =
            "Unassigned";

        if (call.acceptedBy) {

            acceptedText =
                `Accepted by ${escapeHTML(call.acceptedBy)}`;

        }


        callElement.innerHTML = `

            <div class="call-header">

                <span class="call-code">
                    CALL #${call.id}
                </span>

                <span class="call-priority ${priorityClass}">
                    ${escapeHTML(call.priority)}
                </span>

            </div>


            <div class="call-message">
                ${escapeHTML(call.message)}
            </div>


            <div class="call-info">

                Department:
                ${escapeHTML(call.department)}

                &nbsp; • &nbsp;

                Caller:
                ${escapeHTML(call.caller)}

                &nbsp; • &nbsp;

                ${acceptedText}

            </div>


            <div class="call-actions">

                <button
                    class="accept-button"
                    onclick="acceptCall(${call.id})"
                >
                    ✓ ACCEPT
                </button>


                <button
                    class="gps-button"
                    onclick="setGPS(${call.id})"
                >
                    📍 GPS
                </button>


                <button
                    class="close-call-button"
                    onclick="closeCall(${call.id})"
                >
                    ✕ CLOSE
                </button>

            </div>

        `;


        callsList.appendChild(callElement);

    });

}


// ==========================================
// Accept call
// ==========================================

function acceptCall(callId) {

    fetch(`https://${GetParentResourceName()}/acceptCall`, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            callId: callId

        })

    });

}


// ==========================================
// GPS
// ==========================================

function setGPS(callId) {

    const call =
        calls[callId];


    if (!call || !call.coords) {
        return;
    }


    fetch(`https://${GetParentResourceName()}/setGPS`, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            x: call.coords.x,

            y: call.coords.y

        })

    });

}


// ==========================================
// Close call
// ==========================================

function closeCall(callId) {

    fetch(`https://${GetParentResourceName()}/closeCall`, {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            callId: callId

        })

    });

}


// ==========================================
// Security
// ==========================================

function escapeHTML(value) {

    if (value === undefined || value === null) {
        return "";
    }

    return String(value)

        .replace(/&/g, "&amp;")

        .replace(/</g, "&lt;")

        .replace(/>/g, "&gt;")

        .replace(/"/g, "&quot;")

        .replace(/'/g, "&#039;");
}


// ==========================================
// Start with no calls
// ==========================================

renderCalls();
```