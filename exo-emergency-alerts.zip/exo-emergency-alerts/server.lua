-- ==========================================================
-- EXO DEVELOPMENT DISPATCH
-- SERVER
-- ==========================================================

print("[EXO Development Dispatch] server.lua loaded successfully")

-- ==========================================================
-- CONFIGURATION
-- ==========================================================

local INCIDENT_RESOURCE = "incident_management"

-- ==========================================================
-- ACTIVE DISPATCH CALLS
-- ==========================================================

local activeCalls = {}

local callId = 0

-- ==========================================================
-- INCIDENT MANAGEMENT CHECK
-- ==========================================================

local function incidentManagementAvailable()

    return GetResourceState(INCIDENT_RESOURCE) == "started"

end

-- ==========================================================
-- SAFE VALUE
-- ==========================================================

local function safeString(value, maxLength)

    if value == nil then
        return ""
    end

    local result = tostring(value)

    if maxLength and #result > maxLength then

        result = result:sub(1, maxLength)

    end

    return result

end

-- ==========================================================
-- GET PLAYER NAME
-- ==========================================================

local function getPlayerName(src)

    return GetPlayerName(src)
        or ("Player " .. tostring(src))

end

-- ==========================================================
-- CREATE INCIDENT FROM DISPATCH
-- ==========================================================

local function createIncidentFromDispatch(call)

    if not call then
        return
    end

    if not incidentManagementAvailable() then

        print(
            "^3[EXO Development Dispatch]^7 Incident Management is not running. " ..
            "Dispatch call will continue normally."
        )

        return

    end

    local coords = call.coords or {}

    local x = tonumber(coords.x) or 0
    local y = tonumber(coords.y) or 0
    local z = tonumber(coords.z) or 0
    local heading = tonumber(coords.heading) or 0

    local incidentData = {

        incidentType =
            call.incidentType
            or "Dispatch Call",

        priority =
            call.priority
            or "HIGH",

        locationName =
            call.locationName
            or "Unknown Location",

        x = x,

        y = y,

        z = z,

        heading = heading,

        description =
            call.message
            or "Dispatch call",

        dispatchCallId =
            call.id

    }

    TriggerEvent(
        "crownside_incident:createFromDispatch",
        incidentData
    )

    print(
        ("^2[EXO Development Dispatch]^7 Incident Management notified for dispatch call #%s.")
        :format(
            tostring(call.id)
        )
    )

end

-- ==========================================================
-- CREATE DISPATCH CALL
-- ==========================================================

RegisterNetEvent(
    "crownside_dispatch:createCall"
)

AddEventHandler(
    "crownside_dispatch:createCall",
    function(data)

        local source = source

        if not data then
            return
        end

        if not data.message then
            return
        end

        -- ==============================================
        -- GENERATE CALL ID
        -- ==============================================

        callId =
            callId + 1

        -- ==============================================
        -- PLAYER
        -- ==============================================

        local playerName =
            getPlayerName(source)

        -- ==============================================
        -- COORDINATES
        -- ==============================================

        local coords =
            data.coords or {}

        -- ==============================================
        -- CREATE CALL
        -- ==============================================

        local call = {

            id =
                callId,

            caller =
                playerName,

            callerId =
                source,

            message =
                safeString(
                    data.message,
                    5000
                ),

            department =
                safeString(
                    data.department,
                    50
                ),

            priority =
                safeString(
                    data.priority,
                    20
                ):upper(),

            incidentType =
                safeString(
                    data.incidentType,
                    100
                ),

            locationName =
                safeString(
                    data.locationName,
                    255
                ),

            coords = {

                x =
                    tonumber(coords.x)
                    or 0,

                y =
                    tonumber(coords.y)
                    or 0,

                z =
                    tonumber(coords.z)
                    or 0,

                heading =
                    tonumber(coords.heading)
                    or 0

            },

            createdAt =
                os.time(),

            acceptedBy =
                nil,

            acceptedById =
                nil,

            closed =
                false

        }

        -- ==============================================
        -- DEFAULT VALUES
        -- ==============================================

        if call.department == "" then

            call.department =
                "police"

        end

        if call.priority == "" then

            call.priority =
                "HIGH"

        end

        if call.incidentType == "" then

            call.incidentType =
                "Dispatch Call"

        end

        if call.locationName == "" then

            call.locationName =
                "Unknown Location"

        end

        -- ==============================================
        -- STORE CALL
        -- ==============================================

        activeCalls[
            callId
        ] = call

        -- ==============================================
        -- SERVER LOG
        -- ==============================================

        print(
            ("[EXO Development Dispatch] Call #%s created by %s")
            :format(
                callId,
                playerName
            )
        )

        print(
            ("[EXO Development Dispatch] Type: %s | Priority: %s | Department: %s")
            :format(
                call.incidentType,
                call.priority,
                call.department
            )
        )

        -- ==============================================
        -- SEND DISPATCH CALL
        -- ==============================================

        TriggerClientEvent(
            "crownside_dispatch:newCall",
            -1,
            call
        )

        -- ==============================================
        -- CREATE INCIDENT MANAGEMENT RECORD
        -- ==============================================

        createIncidentFromDispatch(
            call
        )

    end
)

-- ==========================================================
-- ACCEPT DISPATCH CALL
-- ==========================================================

RegisterNetEvent(
    "crownside_dispatch:acceptCall"
)

AddEventHandler(
    "crownside_dispatch:acceptCall",
    function(callId)

        local source = source

        local playerName =
            getPlayerName(source)

        callId =
            tonumber(callId)

        if not callId then
            return
        end

        local call =
            activeCalls[callId]

        if not call then
            return
        end

        -- ==============================================
        -- ACCEPT CALL
        -- ==============================================

        call.acceptedBy =
            playerName

        call.acceptedById =
            source

        call.acceptedAt =
            os.time()

        -- ==============================================
        -- BROADCAST
        -- ==============================================

        TriggerClientEvent(
            "crownside_dispatch:callAccepted",
            -1,
            callId,
            playerName
        )

        -- ==============================================
        -- LOG
        -- ==============================================

        print(
            ("[EXO Development Dispatch] Call #%s accepted by %s")
            :format(
                callId,
                playerName
            )
        )

    end
)

-- ==========================================================
-- CLOSE DISPATCH CALL
-- ==========================================================

RegisterNetEvent(
    "crownside_dispatch:closeCall"
)

AddEventHandler(
    "crownside_dispatch:closeCall",
    function(callId)

        local source = source

        callId =
            tonumber(callId)

        if not callId then
            return
        end

        local call =
            activeCalls[callId]

        if not call then
            return
        end

        -- ==============================================
        -- CLOSE CALL
        -- ==============================================

        call.closed =
            true

        call.closedBy =
            getPlayerName(source)

        call.closedById =
            source

        call.closedAt =
            os.time()

        -- ==============================================
        -- BROADCAST
        -- ==============================================

        TriggerClientEvent(
            "crownside_dispatch:callClosed",
            -1,
            callId
        )

        -- ==============================================
        -- LOG
        -- ==============================================

        print(
            ("[EXO Development Dispatch] Call #%s closed by %s.")
            :format(
                callId,
                getPlayerName(source)
            )
        )

        -- ==============================================
        -- REMOVE FROM ACTIVE CALLS
        -- ==============================================

        activeCalls[
            callId
        ] = nil

    end
)

-- ==========================================================
-- GET ACTIVE CALLS
-- ==========================================================

RegisterNetEvent(
    "crownside_dispatch:getActiveCalls"
)

AddEventHandler(
    "crownside_dispatch:getActiveCalls",
    function()

        local source = source

        local calls = {}

        for id, call in pairs(
            activeCalls
        ) do

            calls[#calls + 1] =
                call

        end

        TriggerClientEvent(
            "crownside_dispatch:activeCalls",
            source,
            calls
        )

    end
)

-- ==========================================================
-- GET SPECIFIC CALL
-- ==========================================================

RegisterNetEvent(
    "crownside_dispatch:getCall"
)

AddEventHandler(
    "crownside_dispatch:getCall",
    function(callId)

        local source = source

        callId =
            tonumber(callId)

        if not callId then
            return
        end

        local call =
            activeCalls[callId]

        if not call then

            TriggerClientEvent(
                "crownside_dispatch:callNotFound",
                source,
                callId
            )

            return

        end

        TriggerClientEvent(
            "crownside_dispatch:callData",
            source,
            call
        )

    end
)

-- ==========================================================
-- UPDATE DISPATCH CALL
-- ==========================================================

RegisterNetEvent(
    "crownside_dispatch:updateCall"
)

AddEventHandler(
    "crownside_dispatch:updateCall",
    function(callId, data)

        callId =
            tonumber(callId)

        if not callId then
            return
        end

        local call =
            activeCalls[callId]

        if not call then
            return
        end

        data =
            data or {}

        -- ==============================================
        -- UPDATE MESSAGE
        -- ==============================================

        if data.message then

            call.message =
                safeString(
                    data.message,
                    5000
                )

        end

        -- ==============================================
        -- UPDATE PRIORITY
        -- ==============================================

        if data.priority then

            call.priority =
                safeString(
                    data.priority,
                    20
                ):upper()

        end

        -- ==============================================
        -- UPDATE DEPARTMENT
        -- ==============================================

        if data.department then

            call.department =
                safeString(
                    data.department,
                    50
                )

        end

        -- ==============================================
        -- UPDATE INCIDENT TYPE
        -- ==============================================

        if data.incidentType then

            call.incidentType =
                safeString(
                    data.incidentType,
                    100
                )

        end

        -- ==============================================
        -- UPDATE LOCATION
        -- ==============================================

        if data.locationName then

            call.locationName =
                safeString(
                    data.locationName,
                    255
                )

        end

        -- ==============================================
        -- UPDATE COORDINATES
        -- ==============================================

        if data.coords then

            call.coords = {

                x =
                    tonumber(data.coords.x)
                    or call.coords.x
                    or 0,

                y =
                    tonumber(data.coords.y)
                    or call.coords.y
                    or 0,

                z =
                    tonumber(data.coords.z)
                    or call.coords.z
                    or 0,

                heading =
                    tonumber(data.coords.heading)
                    or call.coords.heading
                    or 0

            }

        end

        call.updatedAt =
            os.time()

        -- ==============================================
        -- BROADCAST UPDATE
        -- ==============================================

        TriggerClientEvent(
            "crownside_dispatch:callUpdated",
            -1,
            call
        )

        print(
            ("[EXO Development Dispatch] Call #%s updated.")
            :format(
                callId
            )
        )

    end
)

-- ==========================================================
-- RESOURCE STOP CLEANUP
-- ==========================================================

AddEventHandler(
    "onResourceStop",
    function(resource)

        if resource ~= GetCurrentResourceName() then
            return
        end

        activeCalls = {}

        print(
            "[EXO Development Dispatch] Active dispatch calls cleared."
        )

    end
)

-- ==========================================================
-- EXPORT: CREATE CALL
-- ==========================================================

exports(
    "CreateCall",
    function(data)

        if not data then
            return nil
        end

        callId =
            callId + 1

        local call = {

            id =
                callId,

            caller =
                data.caller
                or "System",

            callerId =
                data.callerId,

            message =
                safeString(
                    data.message,
                    5000
                ),

            department =
                safeString(
                    data.department,
                    50
                ),

            priority =
                safeString(
                    data.priority,
                    20
                ):upper(),

            incidentType =
                safeString(
                    data.incidentType,
                    100
                ),

            locationName =
                safeString(
                    data.locationName,
                    255
                ),

            coords =
                data.coords
                or {
                    x = 0,
                    y = 0,
                    z = 0,
                    heading = 0
                },

            createdAt =
                os.time(),

            acceptedBy =
                nil,

            acceptedById =
                nil,

            closed =
                false

        }

        if call.department == "" then
            call.department = "police"
        end

        if call.priority == "" then
            call.priority = "HIGH"
        end

        if call.incidentType == "" then
            call.incidentType = "Dispatch Call"
        end

        if call.locationName == "" then
            call.locationName = "Unknown Location"
        end

        activeCalls[
            callId
        ] = call

        TriggerClientEvent(
            "crownside_dispatch:newCall",
            -1,
            call
        )

        createIncidentFromDispatch(
            call
        )

        print(
            ("[EXO Development Dispatch] System call #%s created.")
            :format(
                callId
            )
        )

        return callId

    end
)

-- ==========================================================
-- EXPORT: GET CALL
-- ==========================================================

exports(
    "GetCall",
    function(callId)

        callId =
            tonumber(callId)

        if not callId then
            return nil
        end

        return activeCalls[
            callId
        ]

    end
)

-- ==========================================================
-- EXPORT: GET ACTIVE CALLS
-- ==========================================================

exports(
    "GetActiveCalls",
    function()

        local calls = {}

        for _, call in pairs(
            activeCalls
        ) do

            calls[#calls + 1] =
                call

        end

        return calls

    end
)

-- ==========================================================
-- EXPORT: CLOSE CALL
-- ==========================================================

exports(
    "CloseCall",
    function(callId)

        callId =
            tonumber(callId)

        if not callId then
            return false
        end

        if not activeCalls[callId] then
            return false
        end

        activeCalls[callId] = nil

        TriggerClientEvent(
            "crownside_dispatch:callClosed",
            -1,
            callId
        )

        print(
            ("[EXO Development Dispatch] Call #%s closed by system.")
            :format(
                callId
            )
        )

        return true

    end
)

-- ==========================================================
-- READY
-- ==========================================================

print(
    "^2==================================================^7"
)

print(
    "^2[EXO Development Dispatch]^7 Server loaded."
)

print(
    "^2[EXO Development Dispatch]^7 Dispatch calls active."
)

print(
    "^2[EXO Development Dispatch]^7 Call acceptance active."
)

print(
    "^2[EXO Development Dispatch]^7 Call closing active."
)

print(
    "^2[EXO Development Dispatch]^7 Incident Management integration active."
)

print(
    "^2[EXO Development Dispatch]^7 Ready."
)

print(
    "^2==================================================^7"
)