local dispatchOpen = false

-- Open dispatch menu
RegisterCommand("999", function()
    OpenDispatch()
end, false)

RegisterKeyMapping(
    "dispatch",
    "Open EXO Development Dispatch",
    "keyboard",
    "F10"
)

function OpenDispatch()

    if dispatchOpen then
        return
    end

    dispatchOpen = true

    SetNuiFocus(true, true)

    SendNUIMessage({
        action = "open"
    })

end


-- Close dispatch menu
RegisterNUICallback("close", function(data, cb)

    dispatchOpen = false

    SetNuiFocus(false, false)

    SendNUIMessage({
        action = "close"
    })

    cb("ok")

end)


-- Create a dispatch call
RegisterNUICallback("createCall", function(data, cb)

    local ped = PlayerPedId()

    local coords = GetEntityCoords(ped)

    TriggerServerEvent(
        "crownside_dispatch:createCall",
        {
            message = data.message,
            department = data.department or "police",
            priority = data.priority or "HIGH",

            coords = {
                x = coords.x,
                y = coords.y,
                z = coords.z
            }
        }
    )

    cb("ok")

end)


-- Receive a new call
RegisterNetEvent("crownside_dispatch:newCall")
AddEventHandler("crownside_dispatch:newCall", function(call)

    SendNUIMessage({
        action = "newCall",
        call = call
    })

end)


-- Call accepted
RegisterNetEvent("crownside_dispatch:callAccepted")
AddEventHandler("crownside_dispatch:callAccepted", function(callId, playerName)

    SendNUIMessage({
        action = "callAccepted",
        callId = callId,
        playerName = playerName
    })

end)


-- Call closed
RegisterNetEvent("crownside_dispatch:callClosed")
AddEventHandler("crownside_dispatch:callClosed", function(callId)

    SendNUIMessage({
        action = "callClosed",
        callId = callId
    })

end)


-- Accept call
RegisterNUICallback("acceptCall", function(data, cb)

    if data.callId then

        TriggerServerEvent(
            "crownside_dispatch:acceptCall",
            data.callId
        )

    end

    cb("ok")

end)


-- Close call
RegisterNUICallback("closeCall", function(data, cb)

    if data.callId then

        TriggerServerEvent(
            "crownside_dispatch:closeCall",
            data.callId
        )

    end

    cb("ok")

end)


-- Put a GPS marker on the call
RegisterNUICallback("setGPS", function(data, cb)

    if data.x and data.y then

        SetNewWaypoint(
            tonumber(data.x),
            tonumber(data.y)
        )

    end

    cb("ok")

end)


-- ESC closes dispatch
CreateThread(function()

    while true do

        Wait(0)

        if dispatchOpen and IsControlJustReleased(0, 322) then

            dispatchOpen = false

            SetNuiFocus(false, false)

            SendNUIMessage({
                action = "close"
            })

        end

    end

end)