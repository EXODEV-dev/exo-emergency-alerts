# EXO Development Dispatch

> 🚨 **Need help, found a bug, or want to suggest something?**
>
> **Join the EXO Development Discord:** `https://discord.gg/kKwdybJyJ`
>
> You can use the Discord to **report bugs, get support, ask questions, suggest improvements, and keep up with future EXO Development projects and releases.**

---

## 📋 About

**EXO Development Dispatch** is a lightweight, standalone-style emergency dispatch system designed for **FiveM UK emergency-services roleplay servers**.

The system provides a simple dispatch interface where players can create, view, accept, GPS-mark, and close emergency calls.

It is designed with UK-style emergency services in mind, including:

* 🚔 Police
* 🚑 Ambulance
* 🚒 Fire & Rescue

The resource uses a clean NUI interface and is designed to be lightweight and easy for server owners to configure.

---

## ✨ Features

### 🚨 Emergency Dispatch

Create emergency dispatch calls directly through the dispatch interface.

Each call can contain:

* Department
* Priority
* Incident details
* Caller
* Call ID
* GPS coordinates
* Acceptance status

---

### 📞 Call Management

Dispatch users can:

* View active calls
* Accept calls
* Close calls
* View the caller
* View the assigned department
* See the current priority
* Set a GPS waypoint to the incident

---

### 📍 GPS

Calls contain the coordinates of the incident.

The **GPS** button allows the player to place a waypoint on the location of the call.

---

### 🏢 Departments

The current configuration includes:

```text
POLICE
AMBULANCE
FIRE & RESCUE
```

Departments can be configured through `config.lua`.

---

### 🔴 Priority System

Calls currently support:

```text
LOW
HIGH
CRITICAL
```

Priority affects how the call is displayed within the dispatch interface.

---

## 🖥️ Dispatch Interface

The resource includes a custom NUI interface.

The interface contains two main sections:

### Active Calls

Displays currently active emergency calls.

Each call displays information such as:

```text
CALL #1

HIGH

Incident details...

Department: police
Caller: Player

[ ACCEPT ] [ GPS ] [ CLOSE ]
```

### Create Call

Allows a player to create a new dispatch call.

The user can select:

* Department
* Priority
* Incident details

The call is then sent to the server and distributed to connected players.

---

# 📁 Installation

1. Download the resource.

2. Place the resource inside your FiveM server's:

```text
resources
```

folder.

3. Make sure the resource contains:

```text
exo-emergency-alerts/
│
├── fxmanifest.lua
├── config.lua
├── client.lua
├── server.lua
│
└── html/
    ├── index.html
    ├── style.css
    └── script.js
```

4. Add the resource to your `server.cfg`:

```cfg
ensure exo-emergency-alerts
```

5. Restart your server or start the resource.

---

# ⚙️ Configuration

The main configuration is located inside:

```text
config.lua
```

Example:

```lua
Config = {}

Config.ServerName = "EXO Development"

Config.Departments = {
    police = {
        label = "POLICE",
        colour = "blue"
    },

    ambulance = {
        label = "AMBULANCE",
        colour = "red"
    },

    fire = {
        label = "FIRE & RESCUE",
        colour = "orange"
    }
}
```

You can use the configuration file to customise the available departments and dispatch call types.

---

# 🎮 Controls

### Open Dispatch

```text
F10
```

### Emergency Command

```text
/999
```

The dispatch interface can also be opened through the configured command.

---

# 🔗 Incident Management

The dispatch resource can communicate with an `incident_management` resource when it is running.

When available, dispatch calls can be passed to the incident-management system.

If the incident-management resource is not running, the dispatch call continues to function normally.

---

# 🛠️ Dependencies

The dispatch system is designed to operate without requiring a framework such as:

* ESX
* QBCore

An optional `incident_management` resource can be used for additional integration.

---

# 🐛 Bug Reports

Found something that isn't working correctly?

Please report it through the **EXO Development Discord**.

When reporting a bug, please include:

* FiveM server version
* Resource version
* Error from the server console
* Error from the F8 console
* What you were doing when the problem occurred
* Any relevant screenshots

This helps us investigate the problem much faster.

---

# 💡 Suggestions

Have an idea for the resource?

We'd love to hear it.

You can suggest:

* New features
* New departments
* UI improvements
* UK emergency-services features
* Integration ideas
* Quality-of-life improvements

Future updates may be based on community feedback.

---

# 🚧 Development Status

**Current Version:** `1.0.0`

**Status:** Initial Release

This resource is actively being developed.

More features and improvements may be added in future releases.

---

# 📜 Credits

**EXO Development**

FiveM resource development for UK emergency-services roleplay communities.

---

# 📢 EXO Development

EXO Development is working towards creating more custom FiveM resources, including:

* 🚔 Emergency-services systems
* 🖥️ NUI interfaces
* 📋 MDT systems
* 🚨 Dispatch systems
* 🚗 Vehicle resources
* 👕 EUP resources
* 🗺️ Maps & MLOs
* ⚙️ Custom FiveM development

For support, bug reports, suggestions, and information about **future EXO Development projects**, join the Discord:

**https://discord.gg/kKwdybJyJ**
